# Python for Bioinformatics Workshop

7-day content with notebooks, slides, and data.