# Slide-Style Markdown

## Slide 1
- Point A
- Point B