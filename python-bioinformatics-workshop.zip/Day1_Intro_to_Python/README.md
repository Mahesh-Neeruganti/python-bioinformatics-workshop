# README

This day covers important concepts and includes notebooks and slides.